//
//  SortTypes.swift
//  To-Do
//
//  Created by Asilbek on 01/08/23.
//

import Foundation

enum SortTypesAvailable: CaseIterable {
    case sortByNameAsc
    case sortByNameDesc
    case sortByDateAsc
    case sortByDateDesc
    
    func getTitleForSortType() -> String {
        var titleString = ""
        switch self {
        case .sortByNameAsc:
            titleString = "Nomi bo'yicha saralash(A-Z)"
        case .sortByNameDesc:
            titleString = "Nomi bo'yicha saralash (Z-A)"
        case .sortByDateAsc:
            titleString = "Sana bo'yicha saralash (Earliest first)"
        case .sortByDateDesc:
            titleString = "Sana bo'yicha saralash (Latest first)"
        }
        return titleString
    }
    
    func getSortDescriptor() -> [NSSortDescriptor] {
        switch self {
        case .sortByNameAsc:
            return [NSSortDescriptor(key: "title", ascending: true)]
        case .sortByNameDesc:
            return [NSSortDescriptor(key: "title", ascending: false)]
        case .sortByDateAsc:
            return [NSSortDescriptor(key: "dueDateTimeStamp", ascending: true)]
        case .sortByDateDesc:
            return [NSSortDescriptor(key: "dueDateTimeStamp", ascending: false)]
        }
    }
}
