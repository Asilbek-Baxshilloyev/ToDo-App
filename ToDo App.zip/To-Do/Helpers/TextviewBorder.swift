//
//  TextviewBorder.swift
//  To-Do
//
//  Created by Asilbek on 01/08/23.
//

import UIKit

extension UITextView{
    func addBorder(){
        self.layer.cornerRadius = 6
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.separator.cgColor
    }
}
