//
//  Constants.swift
//  To-Do
//
//  Created by Asilbek on 01/08/23.
//

import Foundation


class Constants {
    
    struct ViewController{
        static let Onboarding = "OnboardingViewController"
        static let ResultsTable = "ResultsTableController"
    }
    
    struct Cell{
        static let taskCell = "todocell"
        static let photoCell = "AttachmentCell"
    }
    
    struct Segue{
        static let taskToTaskDetail = "gototask"
    }
    
    struct Key{
        static let onboarding = "already_shown_onboarding"
    }
    
    struct Action{
        static let star = "Yulduzcha qo'yish"
        static let unstar = "Yulduzchani olib tashlash"
        static let add = "Qo'shish"
        static let update = "Yangilash"
        static let delete = "O'chirish"
        static let complete = "Yakunlandi"
        static let cancel = "Bekor qilish"
    }
}
