//
//  Extensions.swift
//  To-Do
//
//  Created by Asilbek on 01/08/23.
//

import Foundation

extension String {
    
    static let empty = ""
    
    func trim() -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
